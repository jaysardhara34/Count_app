import 'package:flutter/material.dart';

class HomeProvider extends ChangeNotifier {
  int i = 1;

  void count() {
    i++;
    notifyListeners();
  }

  void mul() {
    i = i * i;
    notifyListeners();
  }

  void mul3() {
    i = i * i * i;
    notifyListeners();
  }

  void mul4() {
    i = i * i * i * i;
    notifyListeners();
  }

  void minus() {
    i--;
    notifyListeners();
  }

  void reset() {
    i = 1;
    notifyListeners();
  }
}
